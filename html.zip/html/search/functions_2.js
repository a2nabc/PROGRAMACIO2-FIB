var searchData=
[
  ['comp_5fratios_111',['comp_ratios',['../class_plataforma__material.html#a61f63e7d66434fa7f75781da0ba3b2c0',1,'Plataforma_material']]],
  ['consultar_5fcurso_5fusuario_112',['consultar_curso_usuario',['../class_usuario.html#a95cc9b10f3412bf2bfcce36f5c67d18e',1,'Usuario']]],
  ['consultar_5fnum_5fsesiones_113',['consultar_num_sesiones',['../class_plataforma__material.html#a1fb598ae194bd90c5d0a8dec16a60401',1,'Plataforma_material']]],
  ['consultar_5fnum_5fsesiones_5fcurso_114',['consultar_num_sesiones_curso',['../class_curso.html#a5614baa62e9aea8ab7b1703a35d92997',1,'Curso']]],
  ['consultar_5fratio_115',['consultar_ratio',['../class_problema.html#aea87780415601a5d3ffd18f613492c56',1,'Problema']]],
  ['consultar_5fsesion_5fi_116',['consultar_sesion_i',['../class_curso.html#a4407a6d24f56bc5e14327015f183e84d',1,'Curso']]],
  ['curso_117',['Curso',['../class_curso.html#ad9dc3a6a6f13484ca9c70625a560f4ad',1,'Curso']]],
  ['curso_5fusuario_118',['curso_usuario',['../class_plataforma__usuarios.html#a70ea5060423f8c0452391659a6806fb1',1,'Plataforma_usuarios']]]
];
