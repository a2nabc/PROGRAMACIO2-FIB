var searchData=
[
  ['verdes_182',['verdes',['../class_usuario.html#a0d96e3b4c0f21e8d316a64fa9cb75fe7',1,'Usuario']]]
];
