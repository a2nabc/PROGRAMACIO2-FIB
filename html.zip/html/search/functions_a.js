var searchData=
[
  ['plataforma_5fmaterial_159',['Plataforma_material',['../class_plataforma__material.html#ab7bc72a82cd8bc1a09ac00e58a669010',1,'Plataforma_material']]],
  ['plataforma_5fusuarios_160',['Plataforma_usuarios',['../class_plataforma__usuarios.html#abdfd76e7f2af09835fa739b5192f14bf',1,'Plataforma_usuarios']]],
  ['problema_161',['Problema',['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema']]],
  ['problemas_5fenviables_162',['problemas_enviables',['../class_plataforma__usuarios.html#a0a72651e90d2ec55543d80916a6b5d8a',1,'Plataforma_usuarios']]],
  ['problemas_5fresueltos_163',['problemas_resueltos',['../class_plataforma__usuarios.html#a32acda001de0b747542a9056839d763d',1,'Plataforma_usuarios']]]
];
