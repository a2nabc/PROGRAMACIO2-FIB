var searchData=
[
  ['nueva_5fsesion_64',['nueva_sesion',['../class_plataforma__material.html#a23a00224e793173a85dfa49b1cb3f7ed',1,'Plataforma_material']]],
  ['nuevo_5fcurso_65',['nuevo_curso',['../class_plataforma__material.html#a5842cb32745c301880ad7ac540093e7b',1,'Plataforma_material']]],
  ['nuevo_5fproblema_66',['nuevo_problema',['../class_plataforma__material.html#a2dcc4df03cc73308f2f2950662225c55',1,'Plataforma_material']]],
  ['num_5fcompletado_67',['num_completado',['../class_curso.html#a979552b827814656cb7a8916ac8b9159',1,'Curso']]],
  ['num_5fproblemas_68',['num_problemas',['../class_sesion.html#a5cba4607a54d36ebcb6530134b411675',1,'Sesion']]],
  ['num_5fusuarios_5finscritos_69',['num_usuarios_inscritos',['../class_curso.html#a622e50c0929b59f157b08eab1b88a681',1,'Curso']]]
];
