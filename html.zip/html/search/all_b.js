var searchData=
[
  ['restar_5finscritos_80',['restar_inscritos',['../class_plataforma__material.html#a6f32841a7b436d942da83a98ca1295fb',1,'Plataforma_material']]]
];
