var searchData=
[
  ['actualizar_5fenviables_0',['actualizar_enviables',['../class_sesion.html#acd70e8cadcd10ea2e718605845d620b7',1,'Sesion']]],
  ['actualizar_5fenviables_5finiciales_1',['actualizar_enviables_iniciales',['../class_sesion.html#a489bc39a2b584130925b61eb96dfc010',1,'Sesion']]],
  ['actualizar_5fproblema_5fplataforma_2',['actualizar_problema_plataforma',['../class_plataforma__material.html#ae1f1f2632b885896cc61de81eef16c85',1,'Plataforma_material']]],
  ['actualizar_5fproblemas_3',['actualizar_problemas',['../class_usuario.html#acfe42343b13d2061fc17a6da4cbcb102',1,'Usuario']]],
  ['alta_5fusuario_4',['alta_usuario',['../class_plataforma__usuarios.html#a7c5832bfdd8591eace78d8cee09e89d5',1,'Plataforma_usuarios']]],
  ['anadir_5fenvio_5fcorrecto_5fproblema_5',['anadir_envio_correcto_problema',['../class_problema.html#a010b19a8065478cee9dd376bcd85d63e',1,'Problema']]],
  ['anadir_5fenvio_5ftotal_5fproblema_6',['anadir_envio_total_problema',['../class_problema.html#a8fc227e8a21368d345b4bface89035bf',1,'Problema']]],
  ['anadir_5fproblema_5fenviable_5fusuario_7',['anadir_problema_enviable_usuario',['../class_usuario.html#a7574b1a18fd6902ae38642146bab1c5c',1,'Usuario']]]
];
