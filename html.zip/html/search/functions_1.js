var searchData=
[
  ['baja_5fusuario_109',['baja_usuario',['../class_plataforma__usuarios.html#a8adec497bccede23e04ce1c9eed9cfb7',1,'Plataforma_usuarios']]],
  ['busca_5fy_5factualiza_110',['busca_y_actualiza',['../class_sesion.html#a13297d4c909f72e9b300df7b987af6c2',1,'Sesion']]]
];
