var searchData=
[
  ['nueva_5fsesion_156',['nueva_sesion',['../class_plataforma__material.html#a23a00224e793173a85dfa49b1cb3f7ed',1,'Plataforma_material']]],
  ['nuevo_5fcurso_157',['nuevo_curso',['../class_plataforma__material.html#a5842cb32745c301880ad7ac540093e7b',1,'Plataforma_material']]],
  ['nuevo_5fproblema_158',['nuevo_problema',['../class_plataforma__material.html#a2dcc4df03cc73308f2f2950662225c55',1,'Plataforma_material']]]
];
