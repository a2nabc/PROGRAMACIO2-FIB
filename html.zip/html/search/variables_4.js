var searchData=
[
  ['problemas_180',['problemas',['../class_curso.html#a56b39dae4abfc058cf57956af639f1cb',1,'Curso::problemas()'],['../class_sesion.html#a7125fb9a733e06305e8e8889926b8d1b',1,'Sesion::problemas()']]]
];
