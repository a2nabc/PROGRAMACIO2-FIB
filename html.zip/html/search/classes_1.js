var searchData=
[
  ['plataforma_5fmaterial_89',['Plataforma_material',['../class_plataforma__material.html',1,'']]],
  ['plataforma_5fusuarios_90',['Plataforma_usuarios',['../class_plataforma__usuarios.html',1,'']]],
  ['problema_91',['Problema',['../class_problema.html',1,'']]]
];
