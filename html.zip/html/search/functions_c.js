var searchData=
[
  ['sesion_165',['Sesion',['../class_sesion.html#adf5a84efa8e2629b30ad89df74cfc0a2',1,'Sesion']]],
  ['sesion_5fproblema_166',['sesion_problema',['../class_plataforma__material.html#ab253a3803dae90d0541aa03e1fad4fe8',1,'Plataforma_material']]]
];
