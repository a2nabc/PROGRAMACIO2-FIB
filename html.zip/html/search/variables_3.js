var searchData=
[
  ['num_5fcompletado_177',['num_completado',['../class_curso.html#a979552b827814656cb7a8916ac8b9159',1,'Curso']]],
  ['num_5fproblemas_178',['num_problemas',['../class_sesion.html#a5cba4607a54d36ebcb6530134b411675',1,'Sesion']]],
  ['num_5fusuarios_5finscritos_179',['num_usuarios_inscritos',['../class_curso.html#a622e50c0929b59f157b08eab1b88a681',1,'Curso']]]
];
