var searchData=
[
  ['enviables_173',['enviables',['../class_usuario.html#a689e8f613f9d2c2cf08b52ab33462d28',1,'Usuario']]],
  ['envios_5fcorrectos_174',['envios_correctos',['../class_problema.html#a086bcfe12a44df13cb5312471fbfa467',1,'Problema']]],
  ['envios_5ftotales_175',['envios_totales',['../class_problema.html#abaee308b1ebcc3c1b3620fffc33a4196',1,'Problema::envios_totales()'],['../class_usuario.html#a593cda8a1a1968ccbdb51599cd384d0a',1,'Usuario::envios_totales()']]]
];
