var searchData=
[
  ['evaluator_3a_20plataforma_20de_20gestión_20de_20problemas_20y_20cursos_20de_20programación_183',['Evaluator: plataforma de gestión de problemas y cursos de programación',['../index.html',1,'']]]
];
