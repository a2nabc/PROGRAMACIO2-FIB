var searchData=
[
  ['plataforma_5fmaterial_70',['Plataforma_material',['../class_plataforma__material.html',1,'Plataforma_material'],['../class_plataforma__material.html#ab7bc72a82cd8bc1a09ac00e58a669010',1,'Plataforma_material::Plataforma_material()']]],
  ['plataforma_5fmaterial_2ehh_71',['Plataforma_material.hh',['../_plataforma__material_8hh.html',1,'']]],
  ['plataforma_5fusuarios_72',['Plataforma_usuarios',['../class_plataforma__usuarios.html',1,'Plataforma_usuarios'],['../class_plataforma__usuarios.html#abdfd76e7f2af09835fa739b5192f14bf',1,'Plataforma_usuarios::Plataforma_usuarios()']]],
  ['plataforma_5fusuarios_2ehh_73',['Plataforma_usuarios.hh',['../_plataforma__usuarios_8hh.html',1,'']]],
  ['problema_74',['Problema',['../class_problema.html',1,'Problema'],['../class_problema.html#a9d81af5f3f42a1b4354ad8f3c022fca3',1,'Problema::Problema()']]],
  ['problema_2ehh_75',['Problema.hh',['../_problema_8hh.html',1,'']]],
  ['problemas_76',['problemas',['../class_curso.html#a56b39dae4abfc058cf57956af639f1cb',1,'Curso::problemas()'],['../class_sesion.html#a7125fb9a733e06305e8e8889926b8d1b',1,'Sesion::problemas()']]],
  ['problemas_5fenviables_77',['problemas_enviables',['../class_plataforma__usuarios.html#a0a72651e90d2ec55543d80916a6b5d8a',1,'Plataforma_usuarios']]],
  ['problemas_5fresueltos_78',['problemas_resueltos',['../class_plataforma__usuarios.html#a32acda001de0b747542a9056839d763d',1,'Plataforma_usuarios']]],
  ['program_2ecc_79',['program.cc',['../program_8cc.html',1,'']]]
];
