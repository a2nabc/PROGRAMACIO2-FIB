var searchData=
[
  ['usuario_85',['Usuario',['../class_usuario.html',1,'Usuario'],['../class_usuario.html#aa85a5371a098dfba5449140d9b8a472f',1,'Usuario::Usuario()']]],
  ['usuario_2ehh_86',['Usuario.hh',['../_usuario_8hh.html',1,'']]]
];
