var searchData=
[
  ['desinscribir_119',['desinscribir',['../class_usuario.html#a97c11c5205bceb63ea477a023c0aa198',1,'Usuario']]],
  ['desinscribir_5fusuario_120',['desinscribir_usuario',['../class_curso.html#ae867b38cc9046d21a10df8d9ca5f6945',1,'Curso']]]
];
