var searchData=
[
  ['main_61',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5fstats_62',['modificar_stats',['../class_curso.html#a9b0726477fccd1cec4bfcceddcc1033b',1,'Curso']]],
  ['modificar_5fstats_5fcurso_63',['modificar_stats_curso',['../class_plataforma__material.html#a22a9e35861e06c0fafd7e9d00ced7670',1,'Plataforma_material']]]
];
